var imgs = [];
var gameImgs = [];
var selectedImgs = [];
var score = 0;
generateImgs();
generateTable();
updateScore();
var moves = 0;

setTimeout(HideImgs, 2000);

function HideImgs() {
	var imgsToHide = document.getElementsByClassName('scored');
	if (imgsToHide.length > 0) {
		var len = imgsToHide.length;
		for (var i = 0; i < len; i++) {
			imgsToHide[0].className = "hidden";
		}
	}
}

function updateScore() {
	document.getElementById('score')
	.innerHTML = score;
}
function updateMoves() {
	document.getElementById('moves')
	.innerHTML = moves;
}

function generateImgs() {
	imgs = [
	'https://www.podstadionem.pl/media/catalog/product/cache/1/thumbnail/695x/9df78eab33525d08d6e5fb8d27136e95/r/m/rm-ktn0922.jpg',
	'https://www.podstadionem.pl/media/catalog/product/cache/1/thumbnail/695x/9df78eab33525d08d6e5fb8d27136e95/r/m/rm-khn02007.jpg',
	'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTbixO2kNQ2cFpmRDStjZLN3pXJsZ8y1HpcZiwCCxPqoA97fBBx',
	'https://www.podstadionem.pl/media/catalog/product/cache/1/thumbnail/695x/9df78eab33525d08d6e5fb8d27136e95/r/m/rm-kan0908.png',
	'https://www.podstadionem.pl/media/catalog/product/cache/1/image/439x500/9df78eab33525d08d6e5fb8d27136e95/r/m/rm-khn0910.png',
	'https://images-na.ssl-images-amazon.com/images/I/61979a%2BmMQL._SY355_.jpg',
	'http://img.fruugo.com/product/3/50/35046503_max.jpg',
	'http://www.idfootballdesk.com/media/upload/image/real-madrid/11/real-madrid-goalie-home-jersey-11-12-casillas-1.jpg'
	];
	
	imgs = shuffle(imgs);
	
	for (var i = 0; i < 8; i++){
	gameImgs.push(imgs[i]);
	gameImgs.push(imgs[i]);
	}
	
	gameImgs = shuffle(gameImgs);
}

function generateTable() {
	var table = document
	.getElementById('game_table');
	var k = 0;
	
	for (var i = 0; i < 4; i++)
	{
		var row = table.insertRow(i);
		for (var j = 0; j < 4; j++)
		{
			var cell = row.insertCell(j);
			var img = document.createElement('img');
			img.id = i.toString() + j.toString();
			img.src = gameImgs[k];
			img.className = "scored";
			img.addEventListener('click',
			function (obj) {selectImg(obj.currentTarget)}, false);
			cell.appendChild(img);
			k++;
		}
	}
}

function selectImg(img) {
	if (img.className == "hidden") 
	{
		img.className = "selected";
		selectedImgs.push(img);
		if (selectedImgs.length == 2) 
		{
			if (areTheSame(selectedImgs[0], selectedImgs[1])) 
			{
				setScored(selectedImgs[0],
			selectedImgs[1]);
			}
			else 
			{
                setTimeout(function(){  
				selectedImgs[0].className = "hidden";
				selectedImgs[1].className = "hidden";
				selectedImgs = [];
                },500);
			}
			
		}
	}
}

function setScored(img1, img2) {
	img1.className = "scored";
	img2.className = "scored";
	score++;
	updateScore();
	
	selectedImgs = [];
	if(score==8)
	{
		alert('Wygrana!!!');
	}
	
}
function setMoves(img1, img2) {
	img1.className = "selected";
	moves++;
	updateMoves();
	img2.className = "selected";
	moves++;
	updateMoves();
	
	
	
	
}

function areTheSame(img1, img2) {
	return img1.src == img2.src;
}

function shuffle(array) {
	return array.sort(() => Math.random() - 0.5);
}